chrome.runtime.onInstalled.addListener(async () => {
  try {
    await chrome.declarativeNetRequest.updateDynamicRules({
      removeRuleIds: [1],
      addRules: [
        {
          id: 1,
          priority: 1,
          action: {
            type: "modifyHeaders",
            requestHeaders: [
              {
                header: "ngrok-skip-browser-warning",
                operation: "set",
                value: "true"
              }
            ]
          },
          condition: {
            urlFilter: "borrower-chaste-crewmate.ngrok-free.dev",
            resourceTypes: [
              "main_frame",
              "sub_frame"
            ]
          }
        }
      ]
    });

    console.log("ngrok header rule installed");
  } catch (e) {
    console.error(e);
  }

  // Default state: widget is ON the first time the extension installs
  const existing = await chrome.storage.local.get(["siteclipEnabled"]);
  if (existing.siteclipEnabled === undefined) {
    await chrome.storage.local.set({ siteclipEnabled: true });
  }
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "get_tab_info") {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const tab = tabs[0];

      sendResponse({
        type: "tab_info",
        url: tab.url,
        title: tab.title
      });
    });

    return true;
  }
});

// Clicking the toolbar (puzzle-piece) icon toggles the widget on/off
chrome.action.onClicked.addListener(async (tab) => {
  const { siteclipEnabled = true } = await chrome.storage.local.get(["siteclipEnabled"]);
  const nextEnabled = !siteclipEnabled;

  await chrome.storage.local.set({ siteclipEnabled: nextEnabled });

  if (tab?.id) {
    try {
      await chrome.tabs.sendMessage(tab.id, {
        type: "toggle_widget",
        enabled: nextEnabled
      });
    } catch (e) {
      // Tab has no content script running (e.g. chrome:// pages) - ignore
    }
  }
});
