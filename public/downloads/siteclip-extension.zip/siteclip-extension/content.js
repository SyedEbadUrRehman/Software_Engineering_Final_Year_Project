let hasReloaded = false;
let toggleBtn = null;
let sidebar = null;

function loadIframeWithRetry() {
  // let url = "http://localhost:8000";
  let url = "https://siteclip.duckdns.org";
  sidebar.src = url;

  let loaded = false;

  sidebar.onload = () => {
    loaded = true;
    console.log("Iframe loaded successfully");
  };

  setTimeout(() => {
    if (!loaded && !hasReloaded) {
      hasReloaded = true;
      console.log("Iframe failed (timeout), retrying...");

      sidebar.src = ""; // reset
      setTimeout(() => {
        sidebar.src = url;
      }, 500);
    }
  }, 3000); // wait 3 seconds
}

function mountWidget() {
  if (toggleBtn || sidebar) return; // already mounted

  toggleBtn = document.createElement('button');
  toggleBtn.id = 'ext-toggle-btn';
  toggleBtn.style.position = 'fixed';
  toggleBtn.style.top = '50%';
  toggleBtn.style.right = '-15px';
  toggleBtn.style.transform = 'translateY(-50%)';
  toggleBtn.style.zIndex = '99999999999999';
  toggleBtn.style.padding = '5px 22px 5px 15px';
  toggleBtn.style.background = 'rgba(165, 162, 162, 0.35)';
  toggleBtn.style.color = '#fff';
  toggleBtn.style.border = 'none';
  toggleBtn.style.borderRadius = '17px';
  toggleBtn.style.cursor = 'pointer';

  const img = document.createElement('img');
  img.src = chrome.runtime.getURL('image/favicon.png');
  img.alt = 'Open Sidebar';
  img.style.width = '24px';
  img.style.height = '24px';

  toggleBtn.appendChild(img);
  document.body.appendChild(toggleBtn);

  sidebar = document.createElement('iframe');
  sidebar.id = "ext-iframe";
  sidebar.style.position = 'fixed';
  sidebar.style.top = '0';
  sidebar.style.right = '0';
  sidebar.style.width = '300px';
  sidebar.style.height = '100%';
  sidebar.style.zIndex = '999999999999';
  sidebar.style.display = 'none';
  sidebar.style.background = '#fff';
  document.body.appendChild(sidebar);
  loadIframeWithRetry();

  // This button now just opens/closes the panel - it does NOT
  // control the master on/off state (that's the toolbar icon).
  toggleBtn.addEventListener('click', () => {
    const isHidden = sidebar.style.display === 'none';

    sidebar.style.display = isHidden ? 'block' : 'none';

    if (isHidden) {
      toggleBtn.style.right = '285px'; // 300px sidebar - 15px overlap
    } else {
      toggleBtn.style.right = '-15px';
    }
  });
}

function unmountWidget() {
  if (toggleBtn) {
    toggleBtn.remove();
    toggleBtn = null;
  }
  if (sidebar) {
    sidebar.remove();
    sidebar = null;
  }
  hasReloaded = false;
}

window.addEventListener("message", (event) => {
  if (event.data === "request_tab_info") {
    chrome.runtime.sendMessage({ type: "get_tab_info" }, (response) => {
      sidebar?.contentWindow.postMessage(response, "*");
    });
  }
  // NEW: Listener for updating an existing post's URL
  if (event.data === "request_tab_info_for_upgrade_url") {
    chrome.runtime.sendMessage({ type: "get_tab_info" }, (response) => {
      // Change the response type so Vue knows what to do with it
      response.type = "tab_info_for_upgrade";
      sidebar?.contentWindow.postMessage(response, "*");
    });
  }
});

// Toolbar-icon toggle (fired from background.js on chrome.action.onClicked)
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "toggle_widget") {
    if (msg.enabled) {
      mountWidget();
    } else {
      unmountWidget();
    }
  }
});

// On page load, mount the widget only if it's currently switched on
// (default is on - see background.js onInstalled)
chrome.storage.local.get(["siteclipEnabled"], (result) => {
  const enabled = result.siteclipEnabled !== false; // default true
  if (enabled) {
    mountWidget();
  }
});
