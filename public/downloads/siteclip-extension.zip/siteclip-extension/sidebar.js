document.addEventListener("DOMContentLoaded", () => {
  const btn = document.getElementById("getInfoBtn");

  btn.addEventListener("click", () => {
    window.parent.postMessage("request_tab_info", "*");
  });

  window.addEventListener("message", (event) => {
    if (event.data && event.data.type === "tab_info") {
      const output = document.getElementById("output");
      output.innerText = `Title: ${event.data.title}\nURL: ${event.data.url}`;
    }
  });
});